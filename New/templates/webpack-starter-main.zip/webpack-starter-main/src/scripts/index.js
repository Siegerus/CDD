import '../styles/index.scss';

console.log('webpack starterkit');
